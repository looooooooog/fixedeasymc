using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace EasyMC.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static EasyMC.Properties.Settings defaultInstance;

		public static EasyMC.Properties.Settings Default
		{
			get
			{
				return EasyMC.Properties.Settings.defaultInstance;
			}
		}

		static Settings()
		{
			EasyMC.Properties.Settings.defaultInstance = (EasyMC.Properties.Settings)SettingsBase.Synchronized(new EasyMC.Properties.Settings());
		}

		public Settings()
		{
		}
	}
}