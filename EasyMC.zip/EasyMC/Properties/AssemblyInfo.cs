﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("easymc.io")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © 2021 easymc.io")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.2.3.0")]
[assembly: AssemblyProduct("EasyMC Client")]
[assembly: AssemblyTitle("EasyMC Client")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.2.3.0")]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("bd7dda94-646b-40ab-bbc8-873b93110709")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
